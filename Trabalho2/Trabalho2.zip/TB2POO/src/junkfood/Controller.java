package junkfood;

import java.util.Scanner;

public class Controller {


	static final int DEFAULT_ESPIRAIS = 3;
	static final int DEFAULT_MAX = 5;

	Maquina maquina;
	Scanner entrada;

	public Controller() {
		maquina = new Maquina(DEFAULT_ESPIRAIS, DEFAULT_MAX);
		entrada = new Scanner(System.in);
	}

	private float toFloat(String string) {
		return Float.parseFloat(string);
	}


	public String oracle(String linha){

		String ui[] = linha.split(" ");

		if(ui[0].equals("Ajuda"))
			return "Mostrar, InserirEspirais, Setar, Resetar, Alterar, InserirDinheiro, Comprar";

		else if(ui[0].equals("Mostrar"))
			return "" + maquina;

		else if(ui[0].equals("Setar"))
			maquina.set(Integer.parseInt(ui[1]),ui[2], Integer.parseInt(ui[3]), Float.parseFloat(ui[4]) );

		else if(ui[0].equals("Resetar"))
			maquina.resetar(Integer.parseInt(ui[1]));

		else if (ui[0].equals("Alterar"))
			maquina.alterarEspiral(Integer.parseInt(ui[1]),ui[2], Integer.parseInt(ui[3]), Float.parseFloat(ui[4]));

		else if(ui[0].equals("InserirDinheiro"))
			maquina.inserirDinheiro(Float.parseFloat(ui[1]));

		else if(ui[0].equals("Comprar"))
			maquina.vender(ui[1]);

		else
			return "Comando incorreto!";
		return "done";
	}
}

