package junkfood;

import java.util.ArrayList;
import java.util.Scanner;

public class Maquina {
	
	float saldo = 0;
	float lucro = 0;
	float troco = 0;

	ArrayList<Espiral> espirais; 

	public Maquina(int quantidadeEspirais, int maximoProdutos) {
		espirais = new ArrayList<Espiral>();
		
		for(int i = 0; i < quantidadeEspirais; i++) {
			this.espirais.add(new Espiral(" - ", 0, 0));
		}
	}

	public boolean set(int indice, String nome, int quantidade, float preco ){

		if(indice < espirais.size()) {

			espirais.get(indice).nome = nome;
			espirais.get(indice).quantidade = quantidade;
			espirais.get(indice).preco = preco;
			return true;
		}
		return false;
	}

	public boolean inserirDinheiro(float valor) {

		if(valor > 0) {
			saldo = saldo + valor;
			return true;
		}else 
			return false;
	}

	public float pedirTroco() {
		troco = saldo;
		return troco;
	}

	public void vender(String nome){

		for(Espiral e: espirais) {
			if(e.nome.equals(nome)) {
				if(saldo >= e.preco) {
					e.quantidade --;

					saldo = saldo - e.preco;
					lucro = lucro + e.preco;
					saldo = saldo - troco;

					System.out.println("Produto"  + nome + "vendido!");
				}
			}else
				throw new RuntimeException("Saldo insuficiente ou produto nao existe!");
		}
	

	}

	public boolean alterarEspiral(int indice, String nome, int quantidade, float preco) {

		if(indice < espirais.size()) {
			espirais.get(indice).nome = nome;
			espirais.get(indice).quantidade = quantidade;
			espirais.get(indice).preco = preco;
			return true;
		}else
			return false;
	}

	public float saldo() {
		return saldo();
	}

	public void resetar(int indice) {

		espirais.get(indice).nome = "-";
		espirais.get(indice).quantidade = 0;
		espirais.get(indice).preco = 0;
	}

	public String toString() {

		String saida = "";

		for(int i = 0; i < espirais.size(); i++) {
			saida = saida + i + " " + espirais.get(i) + "\n";
		}
		return saida;
	}
}