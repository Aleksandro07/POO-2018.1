package junkfood;

public class Espiral {

	String nome = "";
	int quantidade = 0;
	double preco = 0;

	public String toString() {
		return "[ " + nome + " - " + quantidade + ":U" + " - "  + preco + ":RS]" + "\n";
	}
}
