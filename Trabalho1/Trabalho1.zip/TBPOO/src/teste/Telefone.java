package teste;

public class Telefone {
	
	public String nome;
	public String id;
	public int telefone;
	
	public Telefone(String nome, int telefone, String id) {
		this.nome = nome;
		this.telefone = telefone;
		this.id = id;
	}
}
