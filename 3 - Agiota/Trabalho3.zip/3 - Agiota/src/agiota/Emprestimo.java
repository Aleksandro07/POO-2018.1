package agiota;

import java.util.ArrayList;

public class Emprestimo {

	float saldo;
	float valor;
	int id = 0;
	ArrayList<Cliente> clientesEmprestimo;

	public Emprestimo(float saldo) {
		this.saldo = saldo;
		clientesEmprestimo = new ArrayList<Cliente>();
	}
	public void iniciarSistema() {

		clientesEmprestimo.clear();
		System.out.println("Sistema inciado com " + saldo + " reais");
	}

	public void cadastrarCliente(String clienteId, String nome) {
		for(Cliente elem : clientesEmprestimo) {
			if(elem.clienteId.equals(clienteId))
				throw new RuntimeException("Fail: cliente " + clienteId + " ja existe");}
		clientesEmprestimo.add(new Cliente(clienteId, nome));
	}

	public void emprestarDinheiro(String clienteId, float valor) {
		if(valor > saldo)
			throw new RuntimeException("Fail: fundos insuficientes");	

		if(saldo >= valor) {
			for(int i = 0; i < clientesEmprestimo.size(); i++)
				if(clientesEmprestimo.get(i).clienteId.equals(clienteId)) {


					for(Cliente elem : clientesEmprestimo) {
						elem.saldoCliente = elem.saldoCliente + valor;
						return;
					}

					this.saldo = saldo - valor;
					System.out.println("id:" + id + " [" + clienteId  + " - " + valor + "]");
					id++;
					return;
				}
		}
	}

	public void receberDinheiro(String clienteId, float valor) {
		for(Cliente elem : clientesEmprestimo) {
			if(elem.clienteId.equals(clienteId)) {
				elem.saldoCliente = elem.saldoCliente - valor;
				this.saldo = saldo + valor;
				return;
			}
		}
		throw new RuntimeException("Fail: cliente " + clienteId + " nao encontrado");
	}

	public void mostrarCliente(String clienteId) {
		for(Cliente elem : clientesEmprestimo)
			if(elem.clienteId.equals(clienteId)) {
				System.out.println(elem.saldoCliente());
			}
	}

	public String mostrarTodosClientes() {
		String saida = "";

		for(int i = 0; i < clientesEmprestimo.size(); i++) 
			saida = saida + clientesEmprestimo.get(i).saldoCliente();
		return saida;
	}

	public void matarCliente(String clientId) {
		for(int i = 0; i < clientesEmprestimo.size(); i++) {
			if(clientesEmprestimo.get(i).clienteId.equals(clientId)) {
				clientesEmprestimo.remove(clientesEmprestimo.get(i));
				return;
			}
		}
		throw new RuntimeException("Fail: cliente " + clientId + " nao existe");
	}
}