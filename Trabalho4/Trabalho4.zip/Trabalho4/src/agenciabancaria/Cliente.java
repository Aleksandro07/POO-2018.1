package agenciabancaria;

public class Cliente {

	private String idCliente;
	private Repositorio<Conta> contas;
	Conta numero;
	
	public Cliente(String idCliente){
		this.idCliente = idCliente;
		this.contas = new Repositorio<Conta>("Contas");

		this.contas.add("" ,new Conta(Conta.ultIdConta));
		Conta.ultIdConta++;

	}

	public void addConta(){

		if(contas == null){
			throw new RuntimeException("Ops, conta nula!");
		}

		int qtd = 0;

		for(Conta c: contas.getAll()){
			if(c.isAtiva()){
				qtd++;
			}
		}

		if(qtd == 2){
			throw new RuntimeException("Limite de contas ativas estourado!");
		}

		this.contas.add("Conta ",numero);
	
	}

	public boolean encerrarConta(int numero){
		for(Conta c : contas.getAll()){
			if(c.getNumero() == numero){
				if(c.getSaldo() == 0){
					c.encerrar();
					return true;
				}
			}
		}

		return false;
	}

	public String getIdCliente() {
		return idCliente;
	}

	public Repositorio<Conta> getContas() {
		return contas;
	}

	public String toString() {
		return "Cliente: " + idCliente;
	}

	public void addConta(int i) {
		
	}
}
