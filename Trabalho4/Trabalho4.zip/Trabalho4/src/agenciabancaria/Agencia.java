package agenciabancaria;

public class Agencia {

	private Repositorio<Cliente> clientes;

	public Agencia(){
		clientes = new Repositorio<Cliente>("Clientes");
	}

	public boolean addCliente(String cpf){
		for(Cliente c: clientes.getAll()){
			
			if(c.getIdCliente().equals(cpf)){
				throw new RuntimeException("CPF já cadastrado");
			}
		}
		
		this.clientes.add("Cliente adicionado, cpf: " + cpf, new Cliente(cpf));
		return true;
	}
	
	public boolean abrirNovaConta(String cpf){
		for(Cliente c: clientes.getAll()){
			if(c.getIdCliente().equals(cpf)){
				c.addConta(Conta.ultIdConta++);
				return true;
			}
		}
		
		return false;
	}

	public Repositorio<Cliente> getClientes(){
		return clientes;
	}
}
