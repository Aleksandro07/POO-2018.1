package agenciabancaria;

public class Controller {

	Repositorio<Cliente> clientes;
	Repositorio<Conta> contas;

	public Controller() {
		clientes = new 	Repositorio<Cliente>("Cliente");
		contas = new Repositorio<Conta>("Conta");
	}

	public String oracle(String line){
		String ui[] = line.split(" ");

		if(ui[0].equals("help"))
			return "addCliente, depositar, sacar, encerrar, saldo, addConta";

		else if(ui[0].equals("addCliente"))
			clientes.add(ui[1], new Cliente(ui[1]));

		else if(ui[0].equals("addConta"))
			contas.add(ui[1], new Conta(Integer.parseInt(ui[1])));

		else if(ui[0].equals("saldo"))
			System.out.println(contas.get(ui[1]).getSaldo());

		else if(ui[0].equals("depositar"))
			contas.get(ui[1]).depositar(Float.parseFloat(ui[2]));

		else if(ui[0].equals("sacar"))
			contas.get(ui[1]).sacar(Float.parseFloat(ui[2]));

		else if(ui[0].equals("encerrar"))
			contas.get(ui[1]).encerrar();
		else if(ui[0].equals("Show")) {

			String saida = "";

			for(Cliente c: clientes.getAll())
				saida = saida + c.getIdCliente() + "\n";
			return saida;
		}
		else
			return "comando invalido";
		return "done";
	}	
}