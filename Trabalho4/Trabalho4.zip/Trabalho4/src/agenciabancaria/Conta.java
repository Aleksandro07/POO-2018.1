package agenciabancaria;

public class Conta {

	public static int ultIdConta = 1;

	private float saldo;
	private int numero;
	private Repositorio<Operacao> extrato;
	private boolean ativa;

	public Conta(int numero){
		this.numero  = numero;
		this.saldo   = saldo + saldo;
		this.extrato = new Repositorio<Operacao>("Contas");
		this.ativa   = true;
	}

	public boolean depositar(float valor){

		if(ativa) {

			if(valor < 0)
				throw new RuntimeException("fail: valor invalido");

			this.extrato.add("", new Operacao("Deposito ", valor));
			this.saldo = saldo + valor;
			return true;
		}

		throw new RuntimeException("fail: conta inativa");
	}

	public boolean sacar(float valor){

		if(valor <= 0){
			throw new RuntimeException("Valor negativo");
		}

		if(valor > saldo){
			throw new RuntimeException("Tentativa de saque maior do que o saldo!");
		}

		this.saldo = saldo - valor;
		this.extrato.add("", new Operacao("Saque ", valor));
		return true;
	}

	public boolean transferir(Conta other, float valor){
		if(!other.isAtiva()){
			throw new RuntimeException("A conta destino está inativa");
		}

		if(this.sacar(valor)){
			other.depositar(valor);
			return true;
		}

		return false;
	}

	public void encerrar(){
		this.ativa = false;
		ultIdConta --;
	}

	public float getSaldo() {
		return saldo;
	}

	public float setSaldo(float saldo) {
		return this.saldo = saldo;
	}

	public int getNumero() {
		return numero;
	}

	public Repositorio<Operacao> getExtrato() {
		return extrato;
	}

	public boolean isAtiva() {
		return ativa;
	}

	public String toString(){
		return numero + " - " + saldo + " - " + extrato + " - "+ ativa;
	}
}
