package agiota;

public class Cliente {
	
	 String vida = "vivo";
	 String apelido;
	 String nome;
	 float saldo = 0;

	public Cliente(String apelido, String nome) {
		this.apelido = apelido;
		this.nome = nome;
	}

	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String clienteSaldoInserido() {
		return "Apelido: " + apelido + "Saldo: " + saldo; 
	}
	
	public String toString() {
		return " " + "Apelido: " + apelido + ": " + "Nome: " + nome + ": " + "Vivo ou Morto: " + vida + "\n";
	}


}
	