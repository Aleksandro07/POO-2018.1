package agiota;

public class Transacao {
	
	String nome;
	float valor;
	float valorTotal = 0;
	int id = 0;
	
	public Transacao(String nome, float valor, int id) {
		this.nome = nome;
		this.valor = valor;
		this.valorTotal = valor + valorTotal;
		this.id = id;
	}
	
	public String toString() {
		return "id: " + id + "apelido: " + nome + "valor: " + valor + "\n";}
}
