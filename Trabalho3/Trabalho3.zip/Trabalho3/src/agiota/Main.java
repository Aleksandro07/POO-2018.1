package agiota;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		int op = 0;
		
		Cliente c1 = new Cliente(null, null);
		Emprestimo  emprestimo = new Emprestimo();
		
		while (true) {
			
			System.out.println("Escolha sua opcao: \n1 - Iniciar Sistema  \n2 - Cadastrar Cliente \n3 - Emprestar \n4 - Receber Dinheiro \n5 - Mostrar Clientes \n6 - Saldo \n7 - Historico de Transacoes \n8 - Matar Cliente \n9 - Mostrar informacoes de um unico cliente");
			
			op = entrada.nextInt();
			switch (op) {
			
			case 1: 
				emprestimo.iniciarSistema();
				//ok
				break;
			
			case 2:
				emprestimo.cadastrarCliente(c1);
				//ok
				break;
			case 3:
				emprestimo.emprestar(null);
				//ok
				break;
			case 4:
				emprestimo.mostrarTransacoes();
				//ok
				break;
			case 5:
				emprestimo.receberDinheiro(null);
				break;
			case 6:
				System.out.println(emprestimo.saldo);
				break;
			case 7:
				System.out.println(emprestimo.historicoTransacoes());
				break;
			case 8:
				emprestimo.matarCliente(null);
				break;
			
				default: System.out.println("Opcao invalida");
			}
		}
		
		
		
		
	}
}
