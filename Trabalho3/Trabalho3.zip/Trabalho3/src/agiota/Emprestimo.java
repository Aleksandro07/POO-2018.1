package agiota;

import java.util.ArrayList;
import java.util.Scanner;

public class Emprestimo {

	ArrayList<Cliente> listaEmprestimo = new ArrayList<Cliente>();
	ArrayList<Transacao> transacoes = new ArrayList<Transacao>();

	Scanner entrada = new Scanner(System.in);

	float saldo;
	int valorNumerico;
	int id;

	public void iniciarSistema() {

		listaEmprestimo.clear();
		System.out.println("Inicie o sistema com a quantiade de dinheiro desejada! ");
		saldo = entrada.nextFloat();
		System.out.println("Sistema inciciado com " + saldo + " RS");
	}

	public void cadastrarCliente(Cliente cliente) {

		System.out.println("Cadastrar");
		System.out.println("Apelido");
		cliente.apelido = entrada.next();
		System.out.println("Nome");
		cliente.nome = entrada.next();


		for(int i = 0; i < listaEmprestimo.size(); i++) 

			if(listaEmprestimo != null && listaEmprestimo.get(i).apelido.equals(cliente.apelido)) 
				throw new RuntimeException("Cliente " + cliente.apelido + " ja existe");

		listaEmprestimo.add(cliente);
	}

	public void emprestar(String apelido) {

		System.out.println("Emprestar: ");
		System.out.println("Apelido");
		apelido = entrada.next();
		System.out.println("Valor");
		valorNumerico = entrada.nextInt();

		if(valorNumerico > saldo) 
			throw new RuntimeException("Fundos insuficientes");

		if(saldo >= valorNumerico) {

			for(int i = 0; i < listaEmprestimo.size(); i++) {
				if(apelido.equals(listaEmprestimo.get(i).apelido)) {
					saldo = saldo - valorNumerico;
					System.out.println("id:" + i + " [" + apelido  + " - " + valorNumerico + "]");

				}

				else

					throw new RuntimeException("Nao existe");
			}
		}

	}

	public void receberDinheiro(String apelido) {

		int valor;

		System.out.println("Digite o valor que gostaria de pagar!");
		valor = entrada.nextInt();
		System.out.println("Apelido");
		apelido = entrada.next();


		if(saldo >= valor) {
			saldo = saldo + valor;

			this.transacoes.add(new Transacao(apelido, valor, id));
			id++;
			return;
		}else {
			throw new RuntimeException("Saldo inferior ao valor adicionado");
		}
	}

	public String mostrarTransacoes() {
		return "Trasacoes: " + transacoes;
	}

	public String mostrarClientes() {

		String saida = "";	

		for(int i = 0; i < listaEmprestimo.size(); i++) 
			saida = saida + " " + this.listaEmprestimo.get(i).toString();

		return saida;	
	}

	public void matarCliente(String apelido) {

		apelido = entrada.next();

		for(int i = 0; i < listaEmprestimo.size(); i++) {
			if(listaEmprestimo.get(i).apelido.equals(apelido)) {
				this.listaEmprestimo.remove(listaEmprestimo.get(i));
				System.out.println("Cliente deletado, Mortooo");
				return;
			}
		}

		throw new RuntimeException("Cliente nao encontrado");
	}

	public void apagarTransacoes(String apelido) {

		System.out.println("Apelido");
		apelido = entrada.next();

		for(int i = 0; i < transacoes.size(); i++) {
			if(transacoes.get(i).nome.equals(apelido)) {
				this.transacoes.remove(transacoes.get(i));
				i--;
			}
		}
	}

	public String historicoTransacoes() {
		return " " + transacoes.toString();
	}
}